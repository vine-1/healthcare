export const API_URL = window.location.hostname === "localhost" ? "http://localhost:8181" : "http://localhost:8181";
console.log(
    "API_URL :",
    API_URL
);